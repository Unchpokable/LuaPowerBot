return function()
    return {
        -- place your data here
        -- do not use hardcoded data - it can be lost due to bytecode serialization
        
        -- do not remove or rename these functions! This is a public API functions that will be called by a runtime
        -- on_start will be executed once when new chat session is created
        on_start = function() 
            -- implement your startup routine here
        end;

        -- on_message will be called every time when bot receives a message
        on_message = function(chat_id, message) 
            -- implement your action on message here
        end;

        -- on_callback will be called every time when bot receives a callback query (InlineKeyboard handling, etc.)
        on_callback = function(chat_id, callback_query) 
            -- implement your action to callback here
        end;
    }
end